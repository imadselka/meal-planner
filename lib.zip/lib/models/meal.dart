class Meal {
  String name;
  String imagePath;
  List<String> listOfIngredient;

  Meal({required this.name, required this.imagePath, required this.listOfIngredient});  
}